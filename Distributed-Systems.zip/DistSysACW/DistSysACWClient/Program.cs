﻿using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Text;
using CoreExtensions;

namespace DistSysACWClient
{
    #region Task 10 and beyond
    class Client
    {
        public static string apiKeyPost;
        public static string usernamePost;
        public static string xmlString;

        static HttpClient client = new HttpClient();
        static void Main(string[] args)
        {
            client.BaseAddress = new Uri("https://localhost:5001/");
            bool bool_value = true;
            bool console_bool = true;
            while (true == true)
            {
                if (console_bool == true)
                {
                    Console.WriteLine("Hello. What would you like to do?");
                    console_bool = false;
                }
                else if (console_bool == false)
                {
                    Console.WriteLine("What would you like to do next?");
                }
                string userInput = Console.ReadLine();
                List<string> UserInput_List = new List<string>();
                foreach (string word in userInput.Split(' '))
                {
                    UserInput_List.Add(word);
                }
                if (UserInput_List.ElementAt(0) == "TalkBack" && UserInput_List.ElementAt(1) == "Hello")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    RunAsync().Wait();
                }
                else if (UserInput_List.ElementAt(0) == "TalkBack" && UserInput_List.ElementAt(1) == "Sort")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    int counter = 0;
                    foreach (string word in UserInput_List)
                    {
                        counter++;
                        if (counter == 3)
                        {
                            string wordNew = word.Trim(new char[] { ' ', '[', ']', ',' });
                            RunAsyncSort(wordNew).Wait();
                        }
                    }
                    if (counter == 2)
                    {
                        RunAsyncSort("").Wait();
                    }
                }
                else if (UserInput_List.ElementAt(0) == "User" && UserInput_List.ElementAt(1) == "Get")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    int counter = 0;
                    foreach (string word in UserInput_List)
                    {
                        counter++;
                        if (counter == 3)
                        {
                            string Username = word;
                            RunAsyncGetUsername(Username).Wait();
                        }
                    }
                    if (counter == 2)
                    {
                        RunAsyncGetUsername("").Wait();
                    }
                }
                else if (UserInput_List.ElementAt(0) == "User" && UserInput_List.ElementAt(1) == "Post")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    int counter = 0;
                    foreach (string word in UserInput_List)
                    {
                        counter++;
                        if (counter == 3)
                        {
                            string usernamePost = word;
                            RunAsyncPostUsername(usernamePost).Wait();
                        }
                    }
                    if (counter == 2)
                    {
                        RunAsyncPostUsername("").Wait();
                    }
                }
                else if (UserInput_List.ElementAt(0) == "User" && UserInput_List.ElementAt(1) == "Set")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    int counter = 0;
                    foreach (string word in UserInput_List)
                    {
                        counter++;
                        if (counter == 4)
                        {
                            usernamePost = UserInput_List[2];
                            apiKeyPost = UserInput_List[3];
                            Console.WriteLine("Stored");
                        }
                    }
                    if (counter < 4)
                    {
                        Console.WriteLine("Input a name and APIKey");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "User" && UserInput_List.ElementAt(1) == "Delete")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    if (!String.IsNullOrEmpty(usernamePost) || !String.IsNullOrEmpty(apiKeyPost))
                    {
                        RunAsyncDeleteUser(usernamePost, apiKeyPost).Wait();
                        usernamePost = null;
                        apiKeyPost = null;
                    }
                    else
                    {
                        Console.WriteLine("You need to do a User Post or User Set first");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "User" && UserInput_List.ElementAt(1) == "Role")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    if (!String.IsNullOrEmpty(usernamePost) || !String.IsNullOrEmpty(apiKeyPost))
                    {
                        int counter = 0;
                        int counterDone = 0;
                        string username = "";
                        string Role = "";
                        foreach (string word in UserInput_List)
                        {
                            counter++;
                            if (counter == 3)
                            {
                                username = word;
                            }
                            if (counter == 4)
                            {
                                Role = word;
                            }
                            if (counter == 4)
                            {
                                RunAsyncUserRole(apiKeyPost, username, Role).Wait();
                                counterDone = 1;
                            }
                        }
                        if (username != "" && Role == "" && counterDone == 0)
                        {
                            RunAsyncUserRole(apiKeyPost, username, "").Wait();
                        }
                        else if (Role != "" && username != "" && counterDone == 0)
                        {
                            RunAsyncUserRole(apiKeyPost, "", Role).Wait();
                        }
                        else if (Role == "" && username == "" && counterDone == 0)
                        {
                            RunAsyncUserRole(apiKeyPost, "", Role).Wait();
                        }

                    }
                    else
                    {
                        Console.WriteLine("You need to do a User Post or User Set first");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "Protected" && UserInput_List.ElementAt(1) == "Hello")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    if (!String.IsNullOrEmpty(usernamePost) || !String.IsNullOrEmpty(apiKeyPost))
                    {
                        RunAsyncProtectedHello(usernamePost, apiKeyPost).Wait();
                    }
                    else
                    {
                        Console.WriteLine("You need to do a User Post or User Set first");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "Protected" && UserInput_List.ElementAt(1) == "SHA1")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    if (!String.IsNullOrEmpty(usernamePost) || !String.IsNullOrEmpty(apiKeyPost))
                    {
                        int counter = 0;
                        foreach (string word in UserInput_List)
                        {
                            counter++;
                            if (counter == 3)
                            {
                                //String message = word;
                                //userInput = userInput.Remove(0, 14);
                                UserInput_List.RemoveRange(0, 2);
                                string message = string.Join(" ", UserInput_List.ToArray());
                                RunAsyncProtectedSHA1Hello(usernamePost, apiKeyPost, message).Wait();
                                break;
                            }
                        }
                        if (counter == 2)
                        {
                            RunAsyncProtectedSHA1Hello(usernamePost, apiKeyPost, "").Wait();
                        }
                    }
                    else
                    {
                        Console.WriteLine("You need to do a User Post or User Set first");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "Protected" && UserInput_List.ElementAt(1) == "SHA256")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    if (!String.IsNullOrEmpty(usernamePost) || !String.IsNullOrEmpty(apiKeyPost))
                    {
                        int counter = 0;
                        foreach (string word in UserInput_List)
                        {
                            counter++;
                            if (counter == 3)
                            {
                                //userInput = userInput.Remove(0, 16);
                                UserInput_List.RemoveRange(0, 2);
                                string message = string.Join(" ", UserInput_List.ToArray());
                                RunAsyncProtectedSHA256Hello(usernamePost, apiKeyPost, message).Wait();
                                break;
                            }
                        }
                        if (counter == 2)
                        {
                            RunAsyncProtectedSHA256Hello(usernamePost, apiKeyPost, "").Wait();
                        }
                    }
                    else
                    {
                        Console.WriteLine("You need to do a User Post or User Set first");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "Protected" && UserInput_List.ElementAt(1) == "Get" && UserInput_List.ElementAt(2) == "PublicKey")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    if (!String.IsNullOrEmpty(usernamePost) || !String.IsNullOrEmpty(apiKeyPost))
                    {
                        RunAsyncPublicKey(apiKeyPost).Wait();
                    }
                    else
                    {
                        Console.WriteLine("You need to do a User Post or User Set first");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "Protected" && UserInput_List.ElementAt(1) == "Sign")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");

                    if (!String.IsNullOrEmpty(usernamePost) || !String.IsNullOrEmpty(apiKeyPost))
                    {
                        int counter = 0;
                        foreach (string word in UserInput_List)
                        {
                            counter++;
                            if (counter == 3)
                            {
                                UserInput_List.RemoveRange(0, 2);
                                string message = string.Join(" ", UserInput_List.ToArray());
                                RunAsyncProtectedSign(apiKeyPost, message).Wait();
                                break;
                            }
                        }
                        if (counter == 2)
                        {
                            RunAsyncProtectedSign(apiKeyPost, "").Wait();
                        }
                    }
                    else
                    {
                        Console.WriteLine("You need to do a User Post or User Set first");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "Protected" && UserInput_List.ElementAt(1) == "AddFifty")
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");

                    if (!String.IsNullOrEmpty(usernamePost) || !String.IsNullOrEmpty(apiKeyPost))
                    {
                        int counter = 0;
                        foreach (string word in UserInput_List)
                        {
                            counter++;
                            if (counter == 3)
                            {
                                UserInput_List.RemoveRange(0, 2);
                                string message = string.Join(" ", UserInput_List.ToArray());
                                RunAsyncAddFifty(apiKeyPost, message).Wait();
                                break;
                            }
                        }
                        if (counter == 2)
                        {
                            RunAsyncAddFifty(apiKeyPost, "").Wait();
                        }
                    }
                    else
                    {
                        Console.WriteLine("You need to do a User Post or User Set first");
                    }
                }
                else if (UserInput_List.ElementAt(0) == "Exit")
                {
                    Environment.Exit(-1);
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("...please wait...");
                    Console.WriteLine("Input a valid command");
                }
            }
        }
        static async Task RunAsync()
        {
            try
            {
                Task<string> task = GetStringAsync("api/talkback/hello");
                if (await Task.WhenAny(task, Task.Delay(20000)) == task)
                {
                    Console.WriteLine(task.Result);
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Request Timed Out");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }
        static async Task RunAsyncSort(string Sort)
        {
            try
            {
                string uri = "api/talkback/sort?";
                foreach (string item in Sort.Split(','))
                {
                    uri += "integers=" + item.ToString() + "&";
                }
                uri = uri.Remove(uri.Length - 1, 1);
                Task<string> task = GetStringAsync(uri);
                if (await Task.WhenAny(task, Task.Delay(20000)) == task)
                {
                    if (task.Result == "[null]")
                    {
                        Console.WriteLine("[]");
                    }
                    else
                    {
                        Console.WriteLine(task.Result);
                    }
                }
                else
                {
                    Console.WriteLine("Request Timed Out");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task RunAsyncGetUsername(string Username)
        {
            try
            {
                string uri = "api/user/new?username=" + Username;
                Task<string> task = GetStringAsync(uri);

                if (await Task.WhenAny(task, Task.Delay(20000)) == task)
                {
                    Console.WriteLine(task.Result);
                }
                else
                {
                    Console.WriteLine("Request Timed Out");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task RunAsyncPostUsername(string Username)
        {
            try
            {
                string uri = "api/user/new";
                Task<string> task = PostStringAsync(uri, Username);

                if (await Task.WhenAny(task, Task.Delay(20000)) == task)
                {
                    Console.WriteLine(task.Result);
                }
                else
                {
                    Console.WriteLine("Request Timed Out");
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task RunAsyncDeleteUser(string Username, string Apikey)
        {
            try
            {
                string uri = "api/user/removeuser?username=" + usernamePost;
                Task<string> task = DeleteUserAsync(uri, Username, Apikey);
                if (await Task.WhenAny(task, Task.Delay(20000)) == task)
                {
                    Console.WriteLine(task.Result);
                }
                else
                {
                    Console.WriteLine("Request Timed Out");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task RunAsyncProtectedHello(string Username, string Apikey)
        {
            try
            {
                string uri = "/api/protected/hello";
                Task<string> task = ProtectedHelloAsync(uri, Username, Apikey);
                if (await Task.WhenAny(task, Task.Delay(20000)) == task)
                {
                    Console.WriteLine(task.Result);
                }
                else
                {
                    Console.WriteLine("Request Timed Out");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task RunAsyncProtectedSHA1Hello(string Username, string Apikey, string message)
        {
            try
            {
                string uri = "api/protected/sha1?message=" + message;
                Task<string> task = ProtectedSHA1HelloAsync(uri, Username, Apikey);
                if (await Task.WhenAny(task, Task.Delay(20000)) == task)
                {
                    Console.WriteLine(task.Result);
                }
                else
                {
                    Console.WriteLine("Request Timed Out");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task RunAsyncProtectedSHA256Hello(string Username, string Apikey, string message)
        {
            try
            {
                string uri = "api/protected/sha256?message=" + message;
                Task<string> task = ProtectedSHA1HelloAsync(uri, Username, Apikey);
                if (await Task.WhenAny(task, Task.Delay(20000)) == task)
                {
                    Console.WriteLine(task.Result);
                }
                else
                {
                    Console.WriteLine("Request Timed Out");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetBaseException().Message);
            }
        }

        static async Task RunAsyncUserRole(string Apikey, string Username, string Role)
        {
            string uri = "api/user/changerole";
            Task<string> task = UserRole(uri, Apikey, Username, Role);
            if (await Task.WhenAny(task, Task.Delay(20000)) == task)
            {
                Console.WriteLine(task.Result);
            }
            else
            {
                Console.WriteLine("Request Timed Out");
            }
        }

        static async Task RunAsyncPublicKey(string Apikey)
        {
            string uri = "api/protected/getpublickey";
            Task<string> task = PublicGet(uri, Apikey);
            if (await Task.WhenAny(task, Task.Delay(20000)) == task)
            {
                Console.WriteLine(task.Result);
            }
            else
            {
                Console.WriteLine("Request Timed Out");
            }
        }

        static async Task RunAsyncProtectedSign(string Apikey, string message)
        {
            string uri = "api/protected/sign?message=" + message;
            Task<string> task = ProtectedSign(uri, Apikey, message);
            if (await Task.WhenAny(task, Task.Delay(20000)) == task)
            {
                Console.WriteLine(task.Result);
            }
            else
            {
                Console.WriteLine("Request Timed Out");
            }
        }
        static async Task RunAsyncAddFifty(string ApiKey, string message)
        {
            Task<string> task = AddFifty(ApiKey, message);
            if (await Task.WhenAny(task, Task.Delay(20000)) == task)
            {
                Console.WriteLine(task.Result);
            }
            else
            {
                Console.WriteLine("Request Timed Out");
            }
        }
        static async Task<string> AddFifty(string ApiKey, string message)
        {
            var outputResult = "";
            bool isNumeric = message.All(char.IsDigit);
            if (isNumeric == true && message != "")
            {
                if (xmlString != null)
                {
                    RSACryptoServiceProvider rSA = new RSACryptoServiceProvider();
                    RSACryptoExtensions.FromXmlStringCore22(rSA, xmlString);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Add("Apikey", ApiKey);
                    AesCryptoServiceProvider aesProvider = new AesCryptoServiceProvider();

                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(message);
                    byte[] encrytedMessage = rSA.Encrypt(msg, false);
                    byte[] encrytedAESKey = rSA.Encrypt(aesProvider.Key, false);
                    byte[] encrytedAESIV = rSA.Encrypt(aesProvider.IV, false);
                    var encrytedMessageHex = BitConverter.ToString(encrytedMessage);
                    var encryptedAESKey = BitConverter.ToString(encrytedAESKey);
                    var encryptedAESIV = BitConverter.ToString(encrytedAESIV);

                    string uri = "api/protected/addfifty?encryptedInteger=" + encrytedMessageHex + "&encryptedsymkey=" + encryptedAESKey + "&encryptedIV=" + encryptedAESIV;
                    Task<HttpResponseMessage> responseMessageReturn = client.GetAsync(uri);
                    var temp = responseMessageReturn.Result;
                    bool isSuccess = temp.IsSuccessStatusCode;
                    var responseMessage = await temp.Content.ReadAsStringAsync();
                    if (isSuccess == true)
                    {
                        responseMessage = responseMessage.Replace("-", "");

                        string outputString;
                        byte[] array1 = StringToByteArray(responseMessage);
                        ICryptoTransform decryptor = aesProvider.CreateDecryptor(aesProvider.Key, aesProvider.IV);

                        using (MemoryStream memoryStream = new MemoryStream(array1))
                        {
                            using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                            {
                                using (StreamReader streamReader = new StreamReader(cryptoStream))
                                {
                                    outputString = streamReader.ReadToEnd();
                                    outputResult = outputString;
                                    return AddFiftyParse(outputResult);
                                }

                            }
                        }
                    }
                    else
                    {
                        outputResult = "An error occurred!";
                        return outputResult;
                    }
                }
                else
                {
                    return "Client doesn’t yet have the public key";
                }
            }
            else
            {
                return "A valid integer must be given!";
            }
        }
        static async Task<string> ProtectedSign(string path, string Apikey, string message)
        {
            var res = "";
            if (xmlString == null)
            {
                res = "Client doesn’t yet have the public key";
            }
            else if (xmlString != null)
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Add("Apikey", Apikey);
                Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
                var temp = responseMessage.Result;
                var isSuccess = temp.IsSuccessStatusCode;
                var result = await temp.Content.ReadAsStringAsync();
                result = result.Replace("-", "");
                if (isSuccess == true)
                {
                    RSACryptoServiceProvider rSAClient = new RSACryptoServiceProvider();
                    rSAClient.FromXmlStringCore22(xmlString);
                    byte[] msg = System.Text.Encoding.ASCII.GetBytes(message);
                    byte[] byteResult = StringToByteArray(result);
                    bool verify = rSAClient.VerifyData(msg, "SHA1", byteResult);

                    if (verify == true)
                    {
                        res = "Message was successfully signed";
                    }
                    else
                    {
                        res = "Message was not successfully signed";
                    }
                }
                else
                {
                    res = "Message was not successfully signed";
                }
            }
            return res;
        }

        static async Task<string> PublicGet(string path, string ApiKey)
        {
            string returnResult = "";
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("Apikey", ApiKey);
            Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
            var temp = responseMessage.Result;
            var isSuccess = temp.IsSuccessStatusCode;
            var result = await temp.Content.ReadAsStringAsync();
            if (isSuccess == true)
            {
                xmlString = result;
                returnResult = "Got Public Key";
            }
            else if (isSuccess == false)
            {
                returnResult = "Couldn’t Get the Public Key";
            }
            return returnResult;
        }
        static async Task<string> UserRole(string path, string Apikey, string username, string role)
        {
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("Apikey", Apikey);

            var JObject = new User
            {
                Username = username,
                Role = role
            };

            var json = JsonConvert.SerializeObject(JObject, Formatting.Indented);
            var stringContent = new StringContent(json, Encoding.UTF8, "application/json");
            Task<HttpResponseMessage> responseMessage = client.PostAsync(path, stringContent);
            var temp = responseMessage.Result;
            var isSuccess = temp.IsSuccessStatusCode;
            var result = await temp.Content.ReadAsStringAsync();
            return result;
        }
        static async Task<string> ProtectedSHA1HelloAsync(string path, string Username, string Apikey)
        {
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("ApiKey", Apikey);
            Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
            var temp = responseMessage.Result;
            var isSuccess = temp.IsSuccessStatusCode;
            var result = await temp.Content.ReadAsStringAsync();
            return result;
        }
        static async Task<string> ProtectedHelloAsync(string path, string Username, string Apikey)
        {
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("ApiKey", Apikey);
            Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
            var temp = responseMessage.Result;
            var isSuccess = temp.IsSuccessStatusCode;
            var result = await temp.Content.ReadAsStringAsync();
            return result;
        }
        static async Task<string> DeleteUserAsync(string path, string Username, string ApiKey)
        {
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("ApiKey", ApiKey);
            var response = await client.DeleteAsync(path);
            var result = await response.Content.ReadAsStringAsync();
            return result;
        }
        static async Task<string> GetStringAsync(string path)
        {
            Task<HttpResponseMessage> responseMessage = client.GetAsync(path);
            var temp = responseMessage.Result;
            var isSuccess = temp.IsSuccessStatusCode;
            var result = await temp.Content.ReadAsStringAsync();
            return result;
        }
        static async Task<string> PostStringAsync(string path, string Username)
        {
            var json = JsonConvert.SerializeObject(Username, Formatting.Indented);
            var stringContent = new StringContent(json, Encoding.UTF8, "application/json");
            Task<HttpResponseMessage> responseMessage = client.PostAsync(path, stringContent);
            var temp = responseMessage.Result;
            var isSuccess = temp.IsSuccessStatusCode;
            var result = await temp.Content.ReadAsStringAsync();
            if ((isSuccess == true) && (result.Length > 0))
            {
                apiKeyPost = result;
                usernamePost = Username;
                return "Got API Key";
            }
            return result;
        }
        public static byte[] StringToByteArray(string hex)
        {
            return Enumerable.Range(0, hex.Length)
                .Where(x => x % 2 == 0)
                .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                .ToArray();
        }
        public static string AddFiftyParse(string Output)
        {
            int x;
            bool parseVal = Int32.TryParse(Output, out x);
            if (parseVal == true)
            {
                return Output;
            }
            else
            {
                return "An error occured";
            }
        }
    }
    #endregion
    public class User
    {
        public string Username { get; set; }
        public string Role { get; set; }
    }
}
