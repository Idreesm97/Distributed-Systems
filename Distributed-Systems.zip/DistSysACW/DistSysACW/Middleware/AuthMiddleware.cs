﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace DistSysACW.Middleware
{
    public class AuthMiddleware
    {
        private readonly RequestDelegate _next;

        public AuthMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context, Models.UserContext dbContext)
        {
            #region Task5
            context.Request.Headers.TryGetValue("Apikey", out var apikey);

            try
            {
                Models.User user = Models.UserDatabaseAccess.checkApiExists(apikey);
                
                string url = context.Request.Path.ToString();
                
                if (url.Contains("/api"))
                {
                    url = url.Replace("/api", "");
                    Models.UserDatabaseAccess.CreateLog("User Requested " + url, apikey, dbContext);
                }
                
                var claims = new List<Claim>();
                claims.Add(new Claim(ClaimTypes.Name, user.UserName));
                claims.Add(new Claim(ClaimTypes.Role, user.Role));

                var claimsIdentity = new ClaimsIdentity(claims, apikey);
                context.User.AddIdentity(claimsIdentity);
            }
            catch(Exception e)
            {
                //catches any expection if can't validate an api using a claim
            }
            // TODO:  Find if a header ‘ApiKey’ exists, and if it does, check the database to determine if the given API Key is valid
            //        Then set the correct roles for the User, using claims
            #endregion

            // Call the next delegate/middleware in the pipeline
            await _next(context);
        }
    }
}
