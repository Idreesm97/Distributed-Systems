﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DistSysACW.Migrations
{
    public partial class MigrationB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "ApiKey",
                table: "Logs",
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Logs_ApiKey",
                table: "Logs",
                column: "ApiKey");

            migrationBuilder.AddForeignKey(
                name: "FK_Logs_Users_ApiKey",
                table: "Logs",
                column: "ApiKey",
                principalTable: "Users",
                principalColumn: "apiKey",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Logs_Users_ApiKey",
                table: "Logs");

            migrationBuilder.DropIndex(
                name: "IX_Logs_ApiKey",
                table: "Logs");

            migrationBuilder.AlterColumn<string>(
                name: "ApiKey",
                table: "Logs",
                nullable: true,
                oldClrType: typeof(string),
                oldNullable: true);
        }
    }
}
