﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace DistSysACW.Singleton
{
    public class RSACryptoServicesProviderSingleton
    {
        private static RSACryptoServicesProviderSingleton instance;
        private static RSACryptoServiceProvider CryptoServiceProvider;

        public static RSACryptoServicesProviderSingleton getInstance()
        {
            if (instance == null)
            {
                instance = new RSACryptoServicesProviderSingleton();
            }
            return instance;
        }
        public RSACryptoServiceProvider RSACrptoserviceProider()
        {
            if (CryptoServiceProvider == null)
            {
                CryptoServiceProvider = new RSACryptoServiceProvider();
            }
            return CryptoServiceProvider;
        }

    }
}
