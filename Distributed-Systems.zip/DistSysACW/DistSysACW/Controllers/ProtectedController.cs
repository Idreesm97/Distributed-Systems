﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography;
using CoreExtensions;
using Microsoft.AspNetCore.Authorization;
using System.IO;

namespace DistSysACW.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ProtectedController : ControllerBase
    {
        protected readonly Models.UserContext _context;
        public ProtectedController(Models.UserContext context)
        {
            _context = context;
        }

        [ActionName("hello")]
        [HttpGet]
        public IActionResult Hello([FromHeader(Name = "ApiKey")] string ApiKey)
        {
            Models.User user = Models.UserDatabaseAccess.checkApiExists(ApiKey);
            bool userExists = Models.UserDatabaseAccess.CheckUserAPIExists(user.apiKey, user.UserName);

            if (userExists == true)
            {
                return Ok("Hello " + user.UserName);
            }
            else
            {
                return Ok(ApiKey + " Not in database");
            }
        }

        [ActionName("SHA1")]
        [HttpGet]
        public IActionResult sha1([FromHeader(Name = "ApiKey")] string ApiKey, [FromQuery] string message)
        {
            Models.User user = Models.UserDatabaseAccess.checkApiExists(ApiKey);
            bool userExists = Models.UserDatabaseAccess.CheckUserAPIExists(user.apiKey, user.UserName);

            if (message == null)
            {
                return BadRequest("Bad Request");
            }
            if (message.Length > 0)
            {
                byte[] asciiByteMessage = System.Text.Encoding.ASCII.GetBytes(message);
                byte[] sha1ByteMessage;
                SHA1 sha1Provider = new SHA1CryptoServiceProvider();
                sha1ByteMessage = sha1Provider.ComputeHash(asciiByteMessage);

                string hexString = Models.UserDatabaseAccess.ByteArrayToHexString(sha1ByteMessage);
                return Ok(hexString);
            }
            else
            {
                return BadRequest("Bad Request");
            }
        }

        [ActionName("SHA256")]
        [HttpGet]
        public IActionResult sha256([FromHeader(Name = "ApiKey")] string ApiKey, [FromQuery] string message)
        {
            Models.User user = Models.UserDatabaseAccess.checkApiExists(ApiKey);
            bool userExists = Models.UserDatabaseAccess.CheckUserAPIExists(user.apiKey, user.UserName);

            if (message == null)
            {
                return BadRequest("Bad Request");
            }

            if (message.Length > 0)
            {
                byte[] asciiByteMessage = System.Text.Encoding.ASCII.GetBytes(message);
                byte[] sha1ByteMessage;
                SHA256 sha1Provider = new SHA256CryptoServiceProvider();
                sha1ByteMessage = sha1Provider.ComputeHash(asciiByteMessage);

                string hexString = Models.UserDatabaseAccess.ByteArrayToHexString(sha1ByteMessage);
                return Ok(hexString);
            }
            else
            {
                return BadRequest("Bad Request");
            }
        }

        [ActionName("GetPublicKey")]
        [HttpGet]
        public IActionResult getPublicKey([FromHeader(Name = "ApiKey")] string ApiKey)
        {
            bool userExists = Models.UserDatabaseAccess.CheckAPIExists(ApiKey);
            if (userExists == true)
            {
                return Ok(CoreExtensions.RSACryptoExtensions.ToXmlStringCore22(DistSysACW.Singleton.RSACryptoServicesProviderSingleton.getInstance().RSACrptoserviceProider()));
            }
            else
            {
                return BadRequest("Bad Request");
            }
        }

        [ActionName("Sign")]
        [HttpGet]
        public IActionResult Sign([FromHeader(Name = "Apikey")]string Apikey, [FromQuery]string message)
        {
            bool userExists = Models.UserDatabaseAccess.CheckAPIExists(Apikey);
            if (message == null || message.Length == 0) 
            { 
                return BadRequest("Bad Request"); 
            }
            if (userExists == true)
            {
                RSACryptoServiceProvider rsa = DistSysACW.Singleton.RSACryptoServicesProviderSingleton.getInstance().RSACrptoserviceProider();
                SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider();
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(message);
                var signed_msg = rsa.SignData(msg, sha1);
                var hexString = BitConverter.ToString(signed_msg);
                return Ok(hexString);
            }
            else
            {
                return BadRequest("Bad Request. Apikey Doesn't Exist");
            }
        }

        [ActionName("AddFifty")]
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult AddFifty([FromHeader(Name = "ApiKey")]string ApiKey, [FromQuery]string EncryptedInteger, [FromQuery]string EncryptedSymKey, [FromQuery]string EncryptedIV)
        {
            try
            {
                bool userExist = Models.UserDatabaseAccess.CheckAPIExists(ApiKey);
                if (userExist == true)
                {
                    EncryptedInteger = EncryptedInteger.Replace("-", "");
                    EncryptedSymKey = EncryptedSymKey.Replace("-", "");
                    EncryptedIV = EncryptedIV.Replace("-", "");
                    RSACryptoServiceProvider rsa = DistSysACW.Singleton.RSACryptoServicesProviderSingleton.getInstance().RSACrptoserviceProider();
                    byte[] EncryptedIntegerByte = StringToByteArray(EncryptedInteger);
                    byte[] EncryptedSysKeyByte = StringToByteArray(EncryptedSymKey);
                    byte[] EncryptedIVByte = StringToByteArray(EncryptedIV);
                    byte[] DecryptedInteger = RSADecrypt(EncryptedIntegerByte, rsa.ExportParameters(true), false);
                    byte[] DecryptedSysKey = RSADecrypt(EncryptedSysKeyByte, rsa.ExportParameters(true), false);
                    byte[] DecryptedIV = RSADecrypt(EncryptedIVByte, rsa.ExportParameters(true), false);
                    string int_val = System.Text.Encoding.UTF8.GetString(DecryptedInteger);
                    int int_val1 = int.Parse(int_val) + 50;


                    AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
                    ICryptoTransform encryptor = aes.CreateEncryptor(DecryptedSysKey, DecryptedIV);
                    byte[] array;
                    using (MemoryStream memoryStream = new MemoryStream())
                    {
                        using (CryptoStream cryptoStream = new CryptoStream((Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                            {
                                streamWriter.Write(int_val1);
                            }
                            array = memoryStream.ToArray();
                        }
                    }
                    string hex_val = BitConverter.ToString(array);
                    return Ok(hex_val);

                }
                else
                {
                    return BadRequest("Bad Request. Apikey Doesn't Exist");
                }
            }
            catch
            {
                return BadRequest("Bad Request"); 
            }
        }
        public static byte[] StringToByteArray(string hex)
        {
            return Enumerable.Range(0, hex.Length)
                .Where(x => x % 2 == 0)
                .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                .ToArray();
        }

        static public byte[] RSADecrypt(byte[] DataToDecrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding)
        {
            try
            {
                byte[] decryptedData;
                //Create a new instance of RSACryptoServiceProvider.
                using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
                {
                    //Import the RSA Key information. This needs
                    //to include the private key information.
                    RSA.ImportParameters(RSAKeyInfo);

                    //Decrypt the passed byte array and specify OAEP padding.
                    //OAEP padding is only available on Microsoft Windows XP or
                    //later.
                    decryptedData = RSA.Decrypt(DataToDecrypt, DoOAEPPadding);
                }
                return decryptedData;
            }
            //Catch and display a CryptographicException
            //to the console.
            catch (CryptographicException e)
            {
                Console.WriteLine(e.ToString());

                return null;
            }

        }

    }
}