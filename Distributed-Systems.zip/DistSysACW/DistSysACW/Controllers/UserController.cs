﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;

namespace DistSysACW.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        protected readonly Models.UserContext _context;
        public UserController (Models.UserContext context)
        {
            _context = context;
        }

        [ActionName("New")]
        [HttpGet]
        public IActionResult Get([FromQuery]string Username)
        {
            bool UserExists = Models.UserDatabaseAccess.checkUsername(Username);
            if (UserExists == true)
            {
                return Ok("True - User Does Exist! Did you mean to do a POST to create a new user?");
            }
            else 
            {
                return Ok("False - User Does Not Exist! Did you mean to do a POST to create a new user?");
            }
        }

        [ActionName("New")]
        [HttpPost]
        public IActionResult Post([FromBody] string Username)
        {
            bool UsernameExists = Models.UserDatabaseAccess.checkUsername(Username);
            
            if ((UsernameExists == false) && (Username != null) && (Username.Length > 0))
            {
                Models.User User = Models.UserDatabaseAccess.CreateUser(Username);
                if (_context.Users.Count() == 0)
                {
                    User.Role = "Admin";
                }
                else
                {
                    User.Role = "User";
                }
                _context.Users.Add(User);
                _context.SaveChanges();
                return Ok(User.apiKey.ToString());
            }
            else if (UsernameExists == true && Username != null)
            {
                return StatusCode(403, "Oops. This username is already in use. Please try again with a new username.");
            }
            else
            {
                return BadRequest("Oops. Make sure your body contains a string with your username and your Content-Type is Content-Type:application/json");
            }
        }

        [ActionName("removeuser")]
        [HttpDelete]
        public IActionResult Delete([FromHeader(Name = "ApiKey")]string Apikey,[FromQuery]string Username)
        {
            Models.User user = Models.UserDatabaseAccess.checkApiExists(Apikey);
            bool Api_UserExist = Models.UserDatabaseAccess.CheckUserAPIExists(Apikey, Username);

            if (Api_UserExist == true && (user.Role == "Admin" || user.Role == "User"))
            {
                Models.UserDatabaseAccess.DeleteUser(_context, Apikey);
                return Ok(true);
            }
            else
            {
                return Ok(false);
            }
        }

        [ActionName("ChangeRole")]
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult ChangeRole([FromHeader(Name = "ApiKey")]string Apikey, [FromBody] Models.User userx)
        {
            try
            {
                Models.User user = Models.UserDatabaseAccess.GetUserFromUsername(userx.UserName);
                if (user == null)
                {
                    return BadRequest("NOT DONE: Username does not exist");
                }
                bool userExists = Models.UserDatabaseAccess.CheckUserAPIExists(user.apiKey, userx.UserName);

                if (userExists == true && (user.Role == "Admin" || user.Role == "User") && (userx.Role == "Admin" || userx.Role == "User"))
                {
                    user.Role = userx.Role;
                    string userRole = user.Role.ToString();
                    Models.UserDatabaseAccess.UpdateRole(_context, user.apiKey, userRole);
                    return Ok("DONE");
                }
                else if (userExists == false)
                {
                    return BadRequest("NOT DONE: Username does not exist");
                }
                else if (userx.Role != "Admin" && userx.Role != "User")
                {
                    return BadRequest("NOT DONE: Role does not exist");
                }
                else
                {
                    return BadRequest("NOT DONE: An error occured");
                }
            }
            catch
            {
                return BadRequest("NOT DONE: An error occured");
            }
        }
    }
}