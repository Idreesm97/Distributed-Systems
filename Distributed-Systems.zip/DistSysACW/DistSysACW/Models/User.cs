﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DistSysACW.Models
{
    public class Log
    {
        [Key]
        public int LogId { get; set; }
        public string LogString { get; set; }
        public DateTime LogDateTime { get; set; }

        [ForeignKey("ApiKey")]
        public string ApiKey { get; set; }

        public Log()
        {

        }

        public Log(string logString)
        {
            this.LogString = logString;
            this.LogDateTime = DateTime.Now;
        }

    }
    public class LogArchive
    {
        public LogArchive()
        {

        }

        public LogArchive(Log log)
        {
            this.LogString = log.LogString;
            this.LogDateTime = log.LogDateTime;
            this.ApiKey = log.ApiKey;
        }

        [Key]
        public string LogId { get; set; }
        public string LogString { get; set; }
        public DateTime LogDateTime { get; set; }

        public string ApiKey { get; set; }

    }

    public class User
    {
        #region Task2
        // TODO: Create a User Class for use with Entity Framework
        // Note that you can use the [key] attribute to set your ApiKey Guid as the primary key 
        

        [Key]
        public string apiKey { get; set; }
        public string UserName { get; set; }
        public string Role { get; set; }

        public virtual ICollection<Log> Logs { get; set; }

        public User()
        {
            Logs = new List<Log>();
        }
        #endregion
    }

    #region Task13?
    // TODO: You may find it useful to add code here for Logging

    #endregion

    public static class UserDatabaseAccess
    {
        #region Task3 
        public static User CreateUser(string Username)
        {
            
            User user = new User
            {
                UserName = Username,
                apiKey = Guid.NewGuid().ToString(),
            };
            return user;
        }
        public static void CreateLog(string details, string apiKey, UserContext context)
        {

            //Find User By ApiKey
            User user = checkApiExists(apiKey);
            Log log = new Log(details) { ApiKey = apiKey };

            user.Logs.Add(log);
            context.Logs.Add(log);
            context.Users.Update(user);
            context.SaveChanges();
        }
        public static bool CheckAPIExists(string Apikey)
        {
            bool isExisting = false;
            var context = new UserContext();
            if (context.Users.Any(x => x.apiKey == Apikey))
            {
                isExisting = true;
                return isExisting;
            }
            else
            {
                isExisting = false;
            }
            return isExisting;
        }

        public static User GetUserFromUsername(string Username)
        {
            var context = new UserContext();
            bool userExits = checkUsername(Username);
            if (userExits == true)
            {
                User user = context.Users.FirstOrDefault(x => x.UserName == Username);
                return user;
            }
            else
            {
                return null;
            }
        }

        public static bool CheckUserAPIExists(string Apikey, string Username)
        {
            try
            {
                User user = checkApiExists(Apikey);
                if (user.UserName == Username)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        public static User checkApiExists(string ApiKey)
        {
            var context = new UserContext();
            bool isExisting = CheckAPIExists(ApiKey);
            if (isExisting == true)
            {
                User user = context.Users.FirstOrDefault(x => x.apiKey == ApiKey);
                return user;
            }
            return null;
        }

        public static void DeleteUser(UserContext context, string Apikey)
        {
            User tempUser = context.Users.FirstOrDefault(x => x.apiKey == Apikey); // checks to see if the given passed Api Key exists in the database, if it does delete the user
            if (tempUser != null)
            {

                foreach (var x in context.Logs)
                {
                    if (x.ApiKey == tempUser.apiKey)
                    {
                        var log = new LogArchive(x);
                        context.Log_Archives.Add(log);
                        context.Logs.Remove(x);
                    }
                }

                context.Users.Remove(tempUser);
                context.SaveChanges();
            }
        }

        public static void UpdateUsername(UserContext context, string ApiKey, string Username)
        {
            User user = context.Users.FirstOrDefault(x => x.apiKey == ApiKey);
            context.Users.Update(user);
            context.SaveChanges();
        }
        public static void UpdateRole(UserContext context, string ApiKey, string Role)
        {
            User user = context.Users.FirstOrDefault(x => x.apiKey == ApiKey);
            user.Role = Role;
            context.Users.Update(user);
            context.SaveChanges();
        }
        public static bool checkUsername(string Username)
        {
            bool isExisting = false;
            var context = new UserContext();
            if (context.Users.Any(x => x.UserName == Username))
            {
                isExisting = true;
                return isExisting;
            }
            else
            {
                return isExisting;
            }
        }

        public static string ByteArrayToHexString(byte[] byteArray)
        {
            string hexString = "";
            if (byteArray != null)
            {
                foreach (byte Byte in byteArray)
                {
                    hexString += Byte.ToString("x2");
                }
            }
            return hexString;
        }
        #endregion
    }


}